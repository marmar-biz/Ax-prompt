# عکس – Next.js + Supabase (PWA RTL)

مراحل در توضیح چت آمده است.
