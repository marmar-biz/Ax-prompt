'use client'
import BottomNav from '@/components/BottomNav'
import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'
export default function Profile(){
  const [email,setEmail]=useState<string|undefined>()
  useEffect(()=>{ supabase.auth.getUser().then(({data})=>setEmail(data.user?.email||undefined)) },[])
  async function signIn(){
    const email=prompt('ایمیل خود را وارد کنید:'); if(!email)return;
    await supabase.auth.signInWithOtp({ email, options:{ emailRedirectTo: (typeof location!=='undefined'?location.origin:'') } })
    alert('لینک ورود به ایمیل شما ارسال شد.')
  }
  async function signOut(){ await supabase.auth.signOut(); location.reload() }
  return(<main className="container pb-20">
    <h1 className="pt-6">پروفایل</h1>
    <div className="card mt-4">
      {email ? (<>
        <div>وارد شده به: <b>{email}</b></div>
        <button onClick={signOut} className="mt-3 px-4 py-2 rounded-xl bg-gray-900 text-white">خروج</button>
      </>) : (<button onClick={signIn} className="px-4 py-2 rounded-xl bg-violet-600 text-white">ورود با ایمیل (OTP)</button>)}
    </div>
    <BottomNav/>
  </main>)
}
