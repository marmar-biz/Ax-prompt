'use client'
import { useEffect, useState } from 'react'
import BottomNav from '@/components/BottomNav'
import { supabase } from '@/lib/supabase'
type Pkg={id:string;title:string;description:string|null;price_rial:number;cover_url:string|null}
export default function Packages(){
  const [items,setItems]=useState<Pkg[]>([])
  useEffect(()=>{ supabase.from('packages').select('id,title,description,price_rial,cover_url').order('created_at',{ascending:false}).then(({data})=>setItems(data||[])) },[])
  return(<main className="container pb-20">
    <h1 className="pt-6">پکیج‌ها</h1>
    <div className="grid grid-cols-1 gap-4 mt-4">
      {items.map(p=>(<div key={p.id} className="card">
        {p.cover_url ? <img src={p.cover_url} alt={p.title} className="w-full h-40 object-cover rounded-xl"/>:null}
        <div className="mt-2 font-semibold">{p.title}</div>
        <div className="text-sm text-gray-600 line-clamp-2">{p.description}</div>
        <div className="mt-2 text-violet-600 font-bold">{(p.price_rial||0).toLocaleString('fa-IR')} ریال</div>
      </div>))}
    </div>
    <BottomNav/>
  </main>)
}
