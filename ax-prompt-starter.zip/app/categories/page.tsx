'use client'
import { useEffect, useState } from 'react'
import BottomNav from '@/components/BottomNav'
import { supabase } from '@/lib/supabase'
type Category={id:string;title:string;emoji:string|null}
export default function Categories(){
  const [cats,setCats]=useState<Category[]>([])
  useEffect(()=>{ supabase.from('categories').select('id,title,emoji').order('order_index',{ascending:true}).then(({data})=>setCats(data||[])) },[])
  return(<main className="container pb-20">
    <h1 className="pt-6">دسته‌بندی‌ها</h1>
    <div className="grid grid-cols-2 gap-4 mt-4">
      {cats.map(c=>(<div key={c.id} className="card">
        <div className="text-3xl">{c.emoji||'📁'}</div>
        <div className="mt-2">{c.title}</div>
      </div>))}
    </div>
    <BottomNav/>
  </main>)
}
